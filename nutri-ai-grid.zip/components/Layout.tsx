
import React from 'react';
import { Home, Scan, ShoppingBag, History, User } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();

  const navItems = [
    { icon: <Home size={22} />, label: 'Home', path: '/' },
    { icon: <Scan size={22} />, label: 'NutriLens', path: '/scan' },
    { icon: <History size={22} />, label: 'History', path: '/history' },
    { icon: <ShoppingBag size={22} />, label: 'Vendors', path: '/vendors' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-[#fdfdfd] text-slate-900 pb-24 font-sans">
      <header className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50 px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 active:scale-95 transition-transform">
          <div className="bg-slate-900 text-emerald-400 p-2 rounded-2xl shadow-lg shadow-emerald-500/10">
            <Scan size={24} />
          </div>
          <h1 className="text-xl font-black tracking-tighter text-slate-900">NUTRI<span className="text-emerald-500">AI</span> GRID</h1>
        </Link>
        <button className="w-10 h-10 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 hover:bg-emerald-50 hover:text-emerald-600 transition-all active:scale-90">
          <User size={20} />
        </button>
      </header>

      <main className="flex-1 w-full max-w-lg mx-auto overflow-x-hidden">
        {children}
      </main>

      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-md bg-slate-900/90 backdrop-blur-xl rounded-[2.5rem] py-3 px-8 shadow-2xl shadow-slate-900/40 z-50 flex justify-between items-center border border-white/10">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-1.5 transition-all duration-300 relative ${
                isActive ? 'text-emerald-400' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {isActive && (
                <div className="absolute -top-3 w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_#10b981]"></div>
              )}
              <div className={`transition-transform duration-300 ${isActive ? 'scale-110' : 'scale-100'}`}>
                {item.icon}
              </div>
              <span className={`text-[9px] font-black uppercase tracking-widest ${isActive ? 'opacity-100' : 'opacity-60'}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};

export default Layout;
