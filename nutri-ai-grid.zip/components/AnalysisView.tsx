
import React from 'react';
import { AnalysisResult } from '../types';
// Added missing MapPin import
import { ArrowRight, CheckCircle2, AlertTriangle, X, Info, Flame, Target, Zap, ChevronRight, Share2, MapPin } from 'lucide-react';

interface AnalysisViewProps {
  data: AnalysisResult;
  onClose: () => void;
}

const AnalysisView: React.FC<AnalysisViewProps> = ({ data, onClose }) => {
  const scoreColor = data.healthScore > 70 ? 'text-emerald-500' : data.healthScore > 40 ? 'text-amber-500' : 'text-rose-500';
  const scoreBg = data.healthScore > 70 ? 'bg-emerald-500' : data.healthScore > 40 ? 'bg-amber-500' : 'bg-rose-500';

  return (
    <div className="animate-in slide-in-from-bottom-8 duration-500 ease-out fill-mode-both pb-10">
      <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-slate-100">
        {/* Header Section */}
        <div className="bg-slate-900 p-8 text-white relative">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Zap size={140} fill="currentColor" />
          </div>
          
          <div className="flex justify-between items-start mb-8 relative z-10">
            <div className="bg-emerald-500/20 text-emerald-400 p-3 rounded-2xl border border-white/10 backdrop-blur-md">
              <Zap size={22} fill="currentColor" />
            </div>
            <div className="flex gap-2">
              <button className="p-3 bg-white/10 hover:bg-white/20 rounded-2xl transition-all active:scale-90">
                <Share2 size={20} />
              </button>
              <button 
                onClick={onClose}
                className="p-3 bg-white/10 hover:bg-white/20 rounded-2xl transition-all active:scale-90"
              >
                <X size={20} />
              </button>
            </div>
          </div>
          
          <div className="relative z-10">
            <span className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2 block">Scan Result</span>
            <h2 className="text-4xl font-black mb-1 tracking-tighter leading-none">{data.dishName}</h2>
            <div className="flex items-center gap-2 mt-4">
              <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-bold">
                <Target size={14} className="text-emerald-400" />
                Contextual Analysis Complete
              </div>
            </div>
          </div>
        </div>

        <div className="p-8 space-y-12">
          {/* Health Score Circular Visualization */}
          <div className="flex flex-col items-center">
            <div className="relative w-48 h-48">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="84"
                  fill="none"
                  stroke="#f8fafc"
                  strokeWidth="16"
                />
                <circle
                  cx="96"
                  cy="96"
                  r="84"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="16"
                  strokeDasharray={527.7}
                  strokeDashoffset={527.7 - (527.7 * data.healthScore) / 100}
                  strokeLinecap="round"
                  className={`${scoreColor} transition-all duration-1000 ease-out`}
                  style={{ filter: 'drop-shadow(0 0 8px currentColor)' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={`text-6xl font-black tracking-tighter ${scoreColor}`}>{data.healthScore}</span>
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Health Index</span>
              </div>
            </div>
            <p className="mt-4 text-xs font-medium text-slate-500 text-center max-w-[200px]">
              {data.healthScore > 70 ? "This meal aligns well with your health goals." : 
               data.healthScore > 40 ? "Consider one of the swaps below to balance this meal." : 
               "High concentration of harmful ingredients detected."}
            </p>
          </div>

          {/* Red Flags Section */}
          {data.concerns.length > 0 && (
            <div className="bg-rose-50 border border-rose-100 rounded-[2.5rem] p-6">
              <h3 className="text-xs font-black uppercase tracking-widest text-rose-500 mb-4 flex items-center gap-2">
                <AlertTriangle size={16} /> Red Flags Detected
              </h3>
              <div className="flex flex-wrap gap-2">
                {data.concerns.map((concern, idx) => (
                  <span key={idx} className="bg-white text-rose-600 text-[11px] font-black px-4 py-2 rounded-2xl border border-rose-100 shadow-sm">
                    {concern}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Detailed Decomposition */}
          <div>
            <div className="flex items-center justify-between mb-6 px-1">
              <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">Ingredient Decomposition</h3>
              <div className="text-[10px] font-black text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg uppercase tracking-wider">AI Verified</div>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {data.ingredients.map((ing, idx) => (
                <div key={idx} className="flex items-center gap-5 p-5 rounded-[2rem] bg-slate-50 border border-slate-100 hover:border-slate-200 transition-all group">
                  <div className={`p-3 rounded-2xl shrink-0 shadow-sm transition-transform group-hover:scale-110 ${
                    ing.impact === 'Healthy' ? 'bg-emerald-500 text-white' :
                    ing.impact === 'Harmful' ? 'bg-rose-500 text-white' :
                    'bg-slate-400 text-white'
                  }`}>
                    {ing.impact === 'Healthy' ? <CheckCircle2 size={20} /> : 
                     ing.impact === 'Harmful' ? <AlertTriangle size={20} /> : 
                     <Info size={20} />}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-black text-slate-800 text-base">{ing.name}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed mt-1">{ing.details}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Hyper-Local Swaps: The Decision Engine */}
          <div className="space-y-6">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">Delhi-Local Swaps</h3>
              <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 text-[9px] font-black rounded-full uppercase tracking-widest">
                <MapPin size={10} /> Okhla Context
              </div>
            </div>
            
            <div className="space-y-5">
              {data.swaps.map((swap, idx) => (
                <div 
                  key={idx} 
                  className={`group relative p-8 rounded-[2.5rem] border-2 transition-all cursor-pointer active:scale-[0.98] ${
                    swap.level === 'Best' ? 'border-emerald-500 bg-emerald-50/30' :
                    swap.level === 'Better' ? 'border-amber-200 bg-amber-50/30' :
                    'border-slate-100 bg-white'
                  }`}
                >
                  <div className={`absolute -top-3 left-8 px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] rounded-full shadow-lg ${
                    swap.level === 'Best' ? 'bg-emerald-600 text-white' :
                    swap.level === 'Better' ? 'bg-amber-500 text-white' :
                    'bg-slate-400 text-white'
                  }`}>
                    {swap.level} Choice
                  </div>
                  
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex-1">
                      <h4 className="font-black text-2xl text-slate-800 group-hover:text-emerald-700 transition-colors leading-none mb-3">{swap.item}</h4>
                      <p className="text-xs text-slate-500 leading-relaxed italic pr-6">
                        "{swap.reason}"
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="flex items-center justify-end gap-1.5 text-slate-900 font-black text-2xl tracking-tighter">
                         <Flame size={20} className="text-orange-500" /> {swap.calories}
                      </div>
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Total Kcal</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 pt-6 border-t border-slate-200/50">
                    <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-2xl border border-slate-100 shadow-sm">
                      <Target size={16} className="text-indigo-500" />
                      <span className="text-xs font-black text-slate-700">{swap.protein} Protein</span>
                    </div>
                    <button className={`ml-auto px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-[0.15em] flex items-center gap-2 transition-all shadow-xl ${
                      swap.level === 'Best' ? 'bg-emerald-600 text-white shadow-emerald-500/20 hover:bg-emerald-700' :
                      'bg-slate-900 text-white shadow-slate-900/10 hover:bg-black'
                    }`}>
                      Swap Now <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisView;
