
import React, { useRef, useState, useEffect } from 'react';
import { Camera, Upload, Loader2, X, AlertCircle, RefreshCw, Zap, ZapOff, Maximize, Minimize } from 'lucide-react';
import { analyzeFoodImage } from '../services/geminiService';
import { AnalysisResult } from '../types';

interface ScannerProps {
  onResult: (result: AnalysisResult, imageBase64: string) => void;
}

const Scanner: React.FC<ScannerProps> = ({ onResult }) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [hasTorch, setHasTorch] = useState(false);
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [maxZoom, setMaxZoom] = useState(1);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const trackRef = useRef<MediaStreamTrack | null>(null);

  const stopCamera = () => {
    if (trackRef.current) {
      trackRef.current.stop();
      trackRef.current = null;
    }
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCapturing(false);
    setIsTorchOn(false);
  };

  const startCamera = async (mode: 'user' | 'environment' = facingMode) => {
    try {
      if (videoRef.current?.srcObject) {
        stopCamera();
      }

      setIsCapturing(true);
      setError(null);
      
      const constraints: MediaStreamConstraints = {
        video: { 
          facingMode: mode,
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        const track = stream.getVideoTracks()[0];
        trackRef.current = track;

        // Check capabilities for zoom and torch
        const capabilities = track.getCapabilities() as any;
        if (capabilities.torch) setHasTorch(true);
        if (capabilities.zoom) {
          setMaxZoom(capabilities.zoom.max || 1);
          setZoomLevel(capabilities.zoom.min || 1);
        }
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setError('Could not access camera. Please check permissions.');
      setIsCapturing(false);
    }
  };

  const toggleCamera = () => {
    const newMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(newMode);
    startCamera(newMode);
  };

  const toggleTorch = async () => {
    if (trackRef.current && hasTorch) {
      try {
        const newTorchState = !isTorchOn;
        await trackRef.current.applyConstraints({
          advanced: [{ torch: newTorchState }] as any
        });
        setIsTorchOn(newTorchState);
      } catch (err) {
        console.error('Torch error:', err);
      }
    }
  };

  const handleZoomChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setZoomLevel(val);
    if (trackRef.current) {
      try {
        await trackRef.current.applyConstraints({
          advanced: [{ zoom: val }] as any
        });
      } catch (err) {
        console.error('Zoom error:', err);
      }
    }
  };

  const processImage = async (base64: string, mimeType: string) => {
    setLoading(true);
    setError(null);
    try {
      const result = await analyzeFoodImage(base64, mimeType);
      
      // Persist to local storage if successful
      const historyKey = 'nutri_grid_history_v1';
      const saved = localStorage.getItem(historyKey);
      let history = [];
      if (saved) {
        try {
          history = JSON.parse(saved);
        } catch (e) {
          console.error("Failed to parse history", e);
        }
      }
      
      const newItem = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        image: base64,
        result: result
      };
      
      const updated = [newItem, ...history].slice(0, 20);
      localStorage.setItem(historyKey, JSON.stringify(updated));
      
      onResult(result, base64);
    } catch (err) {
      console.error('Analysis Error:', err);
      setError('Failed to analyze image. Please try a clearer photo.');
    } finally {
      setLoading(false);
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.8);
        const base64 = dataUrl.split(',')[1];
        stopCamera();
        processImage(base64, 'image/jpeg');
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        const mimeType = result.match(/data:([^;]+);base64,/)?.[1] || 'image/jpeg';
        const base64 = result.split(',')[1];
        processImage(base64, mimeType);
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center animate-in fade-in zoom-in duration-300">
        <div className="relative">
          <Loader2 className="animate-spin text-emerald-600 mb-4" size={48} />
          <div className="absolute inset-0 animate-ping rounded-full border-4 border-emerald-100 opacity-75"></div>
        </div>
        <h3 className="text-xl font-bold mb-2">Analyzing Nutrition...</h3>
        <p className="text-slate-500 max-w-xs text-sm">Our AI is decomposing ingredients and mapping local Delhi swaps.</p>
      </div>
    );
  }

  return (
    <div className="w-full">
      {error && (
        <div className="bg-rose-50 text-rose-700 p-4 rounded-2xl mb-4 flex items-start gap-3 border border-rose-100 animate-in slide-in-from-top-2">
          <AlertCircle size={20} className="mt-0.5 shrink-0" />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      {!isCapturing ? (
        <div className="grid grid-cols-1 gap-4">
          <button
            onClick={() => startCamera()}
            className="flex flex-col items-center justify-center gap-4 bg-slate-900 hover:bg-black text-white p-12 rounded-[2.5rem] transition-all shadow-xl active:scale-95 group relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="bg-white/10 p-5 rounded-3xl group-hover:scale-110 transition-transform relative z-10">
              <Camera size={40} className="text-emerald-400" />
            </div>
            <div className="text-center relative z-10">
              <span className="text-xl font-black block tracking-tight">Open NutriLens</span>
              <span className="text-slate-400 text-xs font-medium">Scan plate or hostel menu</span>
            </div>
          </button>

          <label className="flex items-center justify-center gap-3 bg-white border-2 border-dashed border-slate-200 hover:border-emerald-400 hover:bg-emerald-50 text-slate-500 p-6 rounded-[2rem] cursor-pointer transition-all active:scale-95">
            <Upload size={20} />
            <span className="font-bold text-sm">Upload from Gallery</span>
            <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} />
          </label>
        </div>
      ) : (
        <div className="relative rounded-[2.5rem] overflow-hidden bg-black shadow-2xl aspect-[4/5] sm:aspect-square group/scanner">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          
          {/* Top Controls */}
          <div className="absolute top-6 left-6 right-6 z-10 flex justify-between items-center">
            <button
              onClick={stopCamera}
              className="bg-black/40 backdrop-blur-md text-white p-2.5 rounded-2xl hover:bg-black/60 transition-colors"
            >
              <X size={20} />
            </button>
            
            <div className="flex gap-2">
              {hasTorch && (
                <button
                  onClick={toggleTorch}
                  className={`p-2.5 rounded-2xl backdrop-blur-md transition-all ${
                    isTorchOn ? 'bg-amber-500 text-white' : 'bg-black/40 text-white hover:bg-black/60'
                  }`}
                >
                  {isTorchOn ? <Zap size={20} fill="currentColor" /> : <ZapOff size={20} />}
                </button>
              )}
              <button
                onClick={toggleCamera}
                className="bg-black/40 backdrop-blur-md text-white p-2.5 rounded-2xl hover:bg-black/60 transition-colors"
              >
                <RefreshCw size={20} />
              </button>
            </div>
          </div>

          {/* Zoom Slider */}
          {maxZoom > 1 && (
            <div className="absolute right-6 top-1/2 -translate-y-1/2 flex flex-col items-center gap-4 bg-black/40 backdrop-blur-md py-4 px-2 rounded-full border border-white/10">
              <Maximize size={14} className="text-white/60" />
              <input 
                type="range"
                min="1"
                max={maxZoom}
                step="0.1"
                value={zoomLevel}
                onChange={handleZoomChange}
                className="h-32 appearance-none bg-emerald-500/20 rounded-full w-1 overflow-hidden"
                style={{ writingMode: 'bt-lr' as any, WebkitAppearance: 'slider-vertical' }}
              />
              <Minimize size={14} className="text-white/60" />
            </div>
          )}

          {/* Bottom Capture Area */}
          <div className="absolute bottom-10 left-0 right-0 flex justify-center px-4">
            <button
              onClick={takePhoto}
              className="w-24 h-24 bg-white rounded-full border-8 border-emerald-500/30 shadow-2xl flex items-center justify-center active:scale-90 transition-transform"
            >
              <div className="w-16 h-16 bg-white rounded-full border-4 border-slate-900 flex items-center justify-center">
                <div className="w-4 h-4 rounded-full bg-emerald-500 animate-pulse"></div>
              </div>
            </button>
          </div>

          <canvas ref={canvasRef} className="hidden" />
          
          {/* Scanning Guides */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 pointer-events-none">
            {/* Corner Borders */}
            <div className="absolute -top-1 -left-1 w-12 h-12 border-t-4 border-l-4 border-emerald-500 rounded-tl-3xl shadow-[0_0_15px_rgba(16,185,129,0.3)]"></div>
            <div className="absolute -top-1 -right-1 w-12 h-12 border-t-4 border-r-4 border-emerald-500 rounded-tr-3xl shadow-[0_0_15px_rgba(16,185,129,0.3)]"></div>
            <div className="absolute -bottom-1 -left-1 w-12 h-12 border-b-4 border-l-4 border-emerald-500 rounded-bl-3xl shadow-[0_0_15px_rgba(16,185,129,0.3)]"></div>
            <div className="absolute -bottom-1 -right-1 w-12 h-12 border-b-4 border-r-4 border-emerald-500 rounded-br-3xl shadow-[0_0_15px_rgba(16,185,129,0.3)]"></div>
            
            {/* Animated Laser Line */}
            <div className="absolute inset-x-0 h-[2px] bg-emerald-500/80 shadow-[0_0_10px_#10b981] animate-[scan_2s_ease-in-out_infinite] top-0"></div>
          </div>
          
          <div className="absolute bottom-4 left-0 right-0 text-center">
            <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">AI Lens Active</span>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes scan {
          0%, 100% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default Scanner;
