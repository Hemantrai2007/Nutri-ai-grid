
import React, { useState } from 'react';
import Scanner from '../components/Scanner';
import AnalysisView from '../components/AnalysisView';
import { AnalysisResult } from '../types';
import { Info, Sparkles, ShieldCheck } from 'lucide-react';

const NutriLens: React.FC = () => {
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const resetScanner = () => {
    setResult(null);
  };

  return (
    <div className="p-5 space-y-6 max-w-2xl mx-auto">
      {!result ? (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-3">
              <Sparkles size={12} /> Live AI Decomposition
            </div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight leading-none mb-2">NutriLens AI</h2>
            <p className="text-slate-500 text-sm leading-relaxed">
              Identify hidden ingredients in Delhi street food and mess plates. 
              Get healthier swaps instantly.
            </p>
          </div>
          
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-[2.6rem] blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
            <Scanner onResult={(data) => setResult(data)} />
          </div>

          <div className="grid grid-cols-1 gap-4 mt-8">
            <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm flex gap-4 items-start">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
                <Info size={20} />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Scan Menus Too</h4>
                <p className="text-xs text-slate-500 leading-relaxed mt-1">
                  Point the camera at any restaurant menu to find the healthiest options available at that location.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm flex gap-4 items-start">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                <ShieldCheck size={20} />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Privacy First</h4>
                <p className="text-xs text-slate-500 leading-relaxed mt-1">
                  Analysis is done contextually. We don't store photos of people, only your food data for tracking.
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <AnalysisView 
          data={result} 
          onClose={resetScanner} 
        />
      )}
    </div>
  );
};

export default NutriLens;
