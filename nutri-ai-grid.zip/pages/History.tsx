
import React, { useState, useEffect } from 'react';
import { History, Calendar, Trash2, ArrowRight, Search, Filter } from 'lucide-react';
import { HistoryItem } from '../types';
import AnalysisView from '../components/AnalysisView';

const STORAGE_KEY = 'nutri_grid_history_v1';

const HistoryPage: React.FC = () => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [viewingItem, setViewingItem] = useState<HistoryItem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  const clearHistory = () => {
    if (window.confirm("Are you sure you want to delete all scans?")) {
      setHistory([]);
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const filteredHistory = history.filter(item => 
    item.result.dishName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (viewingItem) {
    return (
      <div className="p-4">
        <AnalysisView 
          data={viewingItem.result} 
          onClose={() => setViewingItem(null)} 
        />
      </div>
    );
  }

  return (
    <div className="p-5 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Your Journey</h2>
          <p className="text-slate-500 text-sm">Last {history.length} food scans</p>
        </div>
        {history.length > 0 && (
          <button 
            onClick={clearHistory}
            className="p-3 text-rose-500 bg-rose-50 rounded-2xl hover:bg-rose-100 transition-colors active:scale-90"
          >
            <Trash2 size={20} />
          </button>
        )}
      </div>

      <div className="relative group">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
          <Search size={18} className="text-slate-400 group-focus-within:text-emerald-500 transition-colors" />
        </div>
        <input 
          type="text"
          placeholder="Search previous meals..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-sm"
        />
      </div>

      {filteredHistory.length === 0 ? (
        <div className="py-20 flex flex-col items-center justify-center text-center px-8">
          <div className="w-20 h-20 bg-slate-100 rounded-[2rem] flex items-center justify-center text-slate-300 mb-6">
            <History size={40} />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-2">No scans found</h3>
          <p className="text-slate-400 text-sm leading-relaxed max-w-xs">
            Start scanning your meals to track your nutrition progress and build your history.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredHistory.map((item) => (
            <div 
              key={item.id}
              onClick={() => setViewingItem(item)}
              className="bg-white rounded-[2rem] p-4 shadow-sm border border-slate-100 hover:border-emerald-200 hover:shadow-md transition-all cursor-pointer group active:scale-[0.98]"
            >
              <div className="flex gap-4">
                <div className="w-24 h-24 rounded-2xl overflow-hidden shrink-0 relative">
                  <img 
                    src={item.image.startsWith('data:') ? item.image : `data:image/jpeg;base64,${item.image}`} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    alt={item.result.dishName}
                  />
                  <div className={`absolute bottom-0 right-0 left-0 text-center py-1 text-[9px] font-black text-white ${
                    item.result.healthScore > 70 ? 'bg-emerald-500' : item.result.healthScore > 40 ? 'bg-amber-500' : 'bg-rose-500'
                  }`}>
                    {item.result.healthScore}%
                  </div>
                </div>
                <div className="flex-1 py-1">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-bold uppercase tracking-wider mb-1">
                    <Calendar size={12} />
                    {new Date(item.timestamp).toLocaleDateString('en-IN', { month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <h3 className="text-lg font-black text-slate-800 leading-tight mb-1 group-hover:text-emerald-600 transition-colors">
                    {item.result.dishName}
                  </h3>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {item.result.concerns.slice(0, 2).map((c, idx) => (
                      <span key={idx} className="text-[9px] font-bold bg-slate-50 text-slate-500 px-2 py-0.5 rounded-lg border border-slate-100">
                        {c}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center justify-center pr-2">
                  <ArrowRight size={20} className="text-slate-200 group-hover:text-emerald-500 transition-colors translate-x-0 group-hover:translate-x-1 duration-300" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoryPage;
