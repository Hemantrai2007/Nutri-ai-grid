
import React, { useState } from 'react';
import { Star, MapPin, Navigation, UtensilsCrossed, Trophy, Tag, Gift, ChevronRight, Check } from 'lucide-react';
import { Vendor } from '../types';

const vendors: Vendor[] = [
  { id: '1', name: "Sharma Ji's Diet Point", rating: 4.8, specialty: "Salads & Tandoori", distance: "350m", tags: ["Hygenic", "Less Oil"] },
  { id: '2', name: "The Healthy Stall", rating: 4.5, specialty: "Sprouts & Shakes", distance: "1.2km", tags: ["No Added Sugar"] },
  { id: '3', name: "Delhi Food Junction", rating: 4.1, specialty: "North Indian", distance: "800m", tags: ["Whole Wheat"] },
  { id: '4', name: "Student Mess A", rating: 3.2, specialty: "Daily Thali", distance: "Inside Campus", tags: ["Value"] },
];

const coupons = [
  { id: 'c1', brand: "Organic Tattva", discount: "25% OFF", code: "NUTRI25", desc: "On whole wheat products" },
  { id: 'c2', brand: "Epigamia", discount: "BOGO", code: "GRIDPRO", desc: "On Greek Yogurts" },
];

const Vendors: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'vendors' | 'coupons'>('vendors');

  return (
    <div className="p-4 space-y-6">
      <div className="flex flex-col gap-1">
        <h2 className="text-2xl font-black text-slate-800 tracking-tight">Ecosystem</h2>
        <p className="text-slate-500 text-sm">Delhi's verified NutriShift network.</p>
      </div>

      {/* Tab Switcher */}
      <div className="bg-slate-100 p-1.5 rounded-2xl flex gap-1">
        <button 
          onClick={() => setActiveTab('vendors')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'vendors' ? 'bg-white shadow-sm text-emerald-600' : 'text-slate-500'
          }`}
        >
          <Trophy size={16} /> Leaderboard
        </button>
        <button 
          onClick={() => setActiveTab('coupons')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'coupons' ? 'bg-white shadow-sm text-emerald-600' : 'text-slate-500'
          }`}
        >
          <Tag size={16} /> Coupons
        </button>
      </div>

      {activeTab === 'vendors' ? (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          {/* Top Rated Hero */}
          <div className="bg-gradient-to-br from-amber-400 to-orange-500 rounded-3xl p-5 text-white shadow-lg shadow-amber-200">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-white/20 rounded-xl backdrop-blur-md">
                <Trophy size={20} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest bg-black/20 px-2 py-1 rounded-lg">Rank #1 This Week</span>
            </div>
            <h3 className="text-xl font-black mb-1">Sharma Ji's Diet Point</h3>
            <p className="text-white/80 text-xs mb-4">Awarded for 98% swap adoption rate in Okhla.</p>
            <div className="flex items-center gap-2">
              <div className="bg-white text-orange-600 px-3 py-1 rounded-full text-[10px] font-black">LEAST OIL USED</div>
              <div className="bg-white/20 text-white px-3 py-1 rounded-full text-[10px] font-black">VERIFIED</div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {vendors.map((vendor, idx) => (
              <div key={vendor.id} className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 flex flex-col gap-4 group">
                <div className="flex justify-between items-start">
                  <div className="flex gap-3">
                    <div className="relative">
                      <div className="w-14 h-14 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center text-slate-400 shrink-0">
                        <UtensilsCrossed size={28} />
                      </div>
                      <div className="absolute -top-1 -left-1 w-6 h-6 bg-slate-800 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                        {idx + 1}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800 group-hover:text-emerald-600 transition-colors">{vendor.name}</h3>
                      <div className="flex items-center gap-1 text-slate-400 text-xs mt-1">
                        <MapPin size={12} />
                        <span>{vendor.distance}</span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-emerald-50 px-2 py-1 rounded-lg flex items-center gap-1">
                    <Star size={14} className="text-amber-500 fill-amber-500" />
                    <span className="text-xs font-black text-emerald-700">{vendor.rating}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {vendor.tags.map(tag => (
                    <span key={tag} className="text-[10px] font-bold px-3 py-1 bg-slate-100 text-slate-500 rounded-full flex items-center gap-1">
                      <Check size={10} className="text-emerald-500" /> {tag}
                    </span>
                  ))}
                </div>

                <div className="flex gap-3 pt-2">
                  <button className="flex-1 bg-slate-900 text-white font-bold py-3 rounded-2xl text-sm transition-transform active:scale-95">
                    View Menu
                  </button>
                  <button className="w-12 h-12 flex items-center justify-center bg-slate-100 rounded-2xl text-slate-500 hover:bg-emerald-50 hover:text-emerald-600 transition-colors">
                    <Navigation size={20} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="bg-emerald-600 rounded-3xl p-6 text-white flex items-center justify-between mb-2">
            <div>
              <h3 className="font-bold text-lg mb-1">Your Rewards</h3>
              <p className="text-emerald-100 text-xs">Unlock more with every swap.</p>
            </div>
            <Gift size={40} className="opacity-40" />
          </div>

          {coupons.map(coupon => (
            <div key={coupon.id} className="relative bg-white border-2 border-dashed border-emerald-200 rounded-3xl p-5 overflow-hidden">
              <div className="absolute top-1/2 -left-3 -translate-y-1/2 w-6 h-6 bg-slate-50 border-r-2 border-dashed border-emerald-200 rounded-full"></div>
              <div className="absolute top-1/2 -right-3 -translate-y-1/2 w-6 h-6 bg-slate-50 border-l-2 border-dashed border-emerald-200 rounded-full"></div>
              
              <div className="flex justify-between items-center mb-3">
                <h4 className="font-black text-slate-800">{coupon.brand}</h4>
                <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black px-2 py-1 rounded-lg">ACTIVE</span>
              </div>
              <div className="flex items-center gap-4 mb-4">
                <div className="text-3xl font-black text-emerald-600">{coupon.discount}</div>
                <div className="text-xs text-slate-500 leading-tight">{coupon.desc}</div>
              </div>
              <button className="w-full bg-emerald-50 text-emerald-700 font-bold py-3 rounded-2xl text-sm border border-emerald-100 hover:bg-emerald-100 transition-colors flex items-center justify-center gap-2">
                Copy Code: <span className="font-black">{coupon.code}</span>
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Vendors;
