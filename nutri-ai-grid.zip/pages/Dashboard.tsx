
import React, { useState, useEffect } from 'react';
import { TrendingUp, Activity, MapPin, Award, Info, AlertCircle, ChevronRight, Zap, Target, Flame } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Link } from 'react-router-dom';

const dummyData = [
  { name: 'Mon', score: 45 },
  { name: 'Tue', score: 52 },
  { name: 'Wed', score: 48 },
  { name: 'Thu', score: 61 },
  { name: 'Fri', score: 55 },
  { name: 'Sat', score: 67 },
  { name: 'Sun', score: 74 },
];

const Dashboard: React.FC = () => {
  const [historyCount, setHistoryCount] = useState(0);
  const [avgScore, setAvgScore] = useState(0);

  useEffect(() => {
    const saved = localStorage.getItem('nutri_grid_history_v1');
    if (saved) {
      try {
        const history = JSON.parse(saved);
        setHistoryCount(history.length);
        if (history.length > 0) {
          const sum = history.reduce((acc: number, item: any) => acc + item.result.healthScore, 0);
          setAvgScore(Math.round(sum / history.length));
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  return (
    <div className="flex flex-col gap-6 pb-8 max-w-lg mx-auto">
      {/* Hero: Premium Card Look */}
      <section className="relative overflow-hidden bg-slate-900 mx-4 mt-4 rounded-[2.5rem] p-8 text-white shadow-2xl shadow-slate-900/20">
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-emerald-500/20 rounded-full blur-[80px]"></div>
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-teal-500/20 rounded-full blur-[80px]"></div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/10 w-fit backdrop-blur-md text-[10px] font-black uppercase tracking-[0.2em] mb-6">
            <Zap size={12} className="text-emerald-400" /> Delhi Nutrition Grid
          </div>
          
          <h2 className="text-4xl font-black leading-[0.9] mb-4 tracking-tighter">
            Eat Better,<br />
            <span className="text-emerald-400 font-outline-2 italic">Not Just Less.</span>
          </h2>
          
          <p className="text-slate-400 text-xs leading-relaxed max-w-[220px] mb-8">
            The hyper-local choice engine for Delhi's students and busy professionals.
          </p>
          
          <Link to="/scan" className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-900 font-black px-6 py-3.5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 text-sm group">
            Start Scanning <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>

      <div className="px-5 space-y-6">
        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-slate-100 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-50 rounded-bl-[2rem] -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div className="relative z-10">
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-2">Avg Health</span>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-black text-slate-800">{avgScore || '--'}</span>
                <span className="text-xs font-bold text-emerald-600">pts</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium">Weekly Baseline</p>
            </div>
          </div>
          
          <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-slate-100 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-16 h-16 bg-amber-50 rounded-bl-[2rem] -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div className="relative z-10">
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-2">Total Scans</span>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-black text-slate-800">{historyCount}</span>
                <span className="text-xs font-bold text-amber-600">meals</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-medium">History depth</p>
            </div>
          </div>
        </div>

        {/* Progress Chart with Modern Card */}
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="font-black text-slate-800 text-lg tracking-tight">Health-Shift Trend</h3>
              <p className="text-xs text-slate-400">Progression over the last 7 days</p>
            </div>
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
              <Activity size={20} />
            </div>
          </div>
          
          <div className="h-48 w-full -ml-8">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dummyData}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip 
                  contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)', padding: '12px' }}
                  labelStyle={{ fontWeight: 'bold', fontSize: '12px', color: '#64748b', marginBottom: '4px' }}
                  itemStyle={{ color: '#059669', fontWeight: '900', fontSize: '14px' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="score" 
                  stroke="#10b981" 
                  strokeWidth={5}
                  fillOpacity={1} 
                  fill="url(#colorScore)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Informative Grid: "Why Delhi?" */}
        <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-[2.5rem] p-8 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Target size={120} />
          </div>
          <div className="relative z-10">
            <h3 className="text-2xl font-black mb-4 tracking-tight leading-tight">Combatting<br/>Decision Fatigue</h3>
            <p className="text-blue-100 text-sm leading-relaxed mb-6">
              Hostelers and PG residents in Delhi make over 200+ food decisions a month. We help you make them better.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10">
                <span className="text-2xl font-black block">40%</span>
                <span className="text-[10px] font-bold text-blue-200 uppercase tracking-wider">Oil Reduction</span>
              </div>
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10">
                <span className="text-2xl font-black block">15+</span>
                <span className="text-[10px] font-bold text-blue-200 uppercase tracking-wider">Local Stalls</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-black text-slate-800 text-lg tracking-tight">Action Items</h3>
            <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full uppercase">Lv. 3 User</span>
          </div>
          
          <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 flex items-center gap-5 group hover:border-emerald-200 transition-all cursor-pointer">
            <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 shrink-0 group-hover:scale-110 transition-transform">
              <Flame size={28} fill="currentColor" />
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-slate-800">Scan Breakfast</h4>
              <p className="text-xs text-slate-500">Hit your 3-day streak target.</p>
            </div>
            <div className="p-2 bg-slate-50 rounded-xl text-slate-300 group-hover:bg-emerald-500 group-hover:text-white transition-all">
              <ChevronRight size={20} />
            </div>
          </div>

          <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 flex items-center gap-5 group hover:border-blue-200 transition-all cursor-pointer">
            <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 shrink-0 group-hover:scale-110 transition-transform">
              <MapPin size={28} fill="currentColor" />
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-slate-800">Explore Nearby</h4>
              <p className="text-xs text-slate-500">Find 4+ rated healthy vendors.</p>
            </div>
            <div className="p-2 bg-slate-50 rounded-xl text-slate-300 group-hover:bg-blue-500 group-hover:text-white transition-all">
              <ChevronRight size={20} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
