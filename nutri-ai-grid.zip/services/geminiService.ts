
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

/**
 * Robustly cleans and parses JSON from the Gemini API response.
 * Handles cases where the model might wrap JSON in markdown blocks.
 */
const parseGeminiJson = (text: string): any => {
  try {
    // Remove markdown code block markers if present
    const cleanText = text
      .replace(/^```json\n?/, '')
      .replace(/\n?```$/, '')
      .trim();
    return JSON.parse(cleanText);
  } catch (error) {
    console.error("JSON Parsing Error. Raw Text:", text);
    throw new Error("Failed to parse AI response. The model output was malformed.");
  }
};

export const analyzeFoodImage = async (base64Image: string, mimeType: string = 'image/jpeg'): Promise<AnalysisResult> => {
  // Initialize right before call to ensure we have the most up-to-date API key
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview', // Upgraded for more robust reasoning and structured output
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: mimeType,
            data: base64Image,
          },
        },
        {
          text: `You are Nutri-AI Grid, an expert nutritionist focusing on Delhi's street food and hostel mess culture.
          
          TASK:
          1. Analyze the provided image of food or a menu.
          2. Decompose the dish into hidden ingredients common in Delhi (oils, refined carbs, proteins).
          3. Calculate a "Health-Shift Score" (0-100) based on nutritional quality for an urban student.
          4. Provide 3 levels of contextual swaps:
             - GOOD: A slightly better version.
             - BETTER: A significantly healthier alternative found nearby.
             - BEST: The optimal health choice in a typical Delhi student area.

          Return the data in the specified JSON format only. Do not repeat the image data or include unnecessary descriptions outside the JSON.`
        },
      ],
    },
    config: {
      responseMimeType: 'application/json',
      // Adding thinking budget to help the model with complex decomposition reasoning
      thinkingConfig: { thinkingBudget: 2000 },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          dishName: { type: Type.STRING },
          healthScore: { type: Type.NUMBER },
          concerns: { type: Type.ARRAY, items: { type: Type.STRING } },
          ingredients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                impact: { type: Type.STRING, enum: ['Healthy', 'Harmful', 'Neutral'] },
                details: { type: Type.STRING }
              },
              required: ['name', 'impact', 'details']
            }
          },
          swaps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                level: { type: Type.STRING, enum: ['Good', 'Better', 'Best'] },
                item: { type: Type.STRING },
                calories: { type: Type.NUMBER },
                protein: { type: Type.STRING },
                reason: { type: Type.STRING }
              },
              required: ['level', 'item', 'calories', 'protein', 'reason']
            }
          }
        },
        required: ['dishName', 'healthScore', 'ingredients', 'swaps', 'concerns']
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response text received from the AI model.");
  }

  return parseGeminiJson(text);
};
